<?php

header("location:web/app.php/usuario/login");

?>
